	const openNav() = () =>
	    document.getElementById("myNav").style.width = "100%";

	/* Close when someone clicks on the "x" symbol inside the overlay */
	const closeNav() = () => 
	  document.getElementById("myNav").style.width = "0%";
